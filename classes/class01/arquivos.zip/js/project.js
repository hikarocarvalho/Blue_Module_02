var valuesid = 0;
var value ="";
function changevideo(valuesid,value){
	var negative = String(-1*(1 + parseInt(valuesid)));
	var positive = String(1 + parseInt(valuesid));
	console.log(positive);
	if((1 + parseInt(valuesid)) != 0){
		if((1 + parseInt(valuesid))<0){
			document.getElementById("" + negative + "").style.display=String(value);
		}else{
			document.getElementById("" + positive + "").style.display=String(value);
		}
	}else{
		document.getElementById("1").style.display="block";
	}
}
function forleft(){
    
    valuesid = document.getElementById("about").dataset.value;
    document.getElementById("about").dataset.value ++;
    if(valuesid == 4){
        document.getElementById("about").dataset.value = 0;
		valuesid = 0;
	}else if(valuesid < 0){
		valuesid = -1 * parseInt(valuesid);

	}
    var angle = parseInt(valuesid) * 90;
	console.log(angle);
    document.getElementById("project").style.transform="translate(0%,0%) rotate3d(0,-1, 0,"+ angle + "deg)";
    
    document.getElementById("about").style.transform="translate(0%,0%) rotate3d(0,1, 0, "+angle+"deg)";
        
    
}
function forright(){
    document.getElementById("about").dataset.value --;
	valuesid = document.getElementById("about").dataset.value;
	if(valuesid <0){
		valuesid = -1 * parseInt(valuesid);
		
		if(valuesid == 4){
			document.getElementById("about").dataset.value = 0;
			valuesid = 0;
		}
	}
    var angle = parseInt(valuesid) * 90;

    document.getElementById("project").style.transform="translate(0%,0%) rotate3d(0,1, 0,"+ angle + "deg)";
    
    document.getElementById("about").style.transform="translate(0%,0%) rotate3d(0,-1, 0, "+angle+"deg)";
        
}

//function change(value){
// 	var lista = ['html','cpp','python'];
// 	for(var i=0;i<3;i++){
// 		document.getElementById(lista[i]).style.display="none";
// 	}
// 	document.getElementById(value).style.display="flex";
// 	if(value === "python"){
// 		lista = ['pypj01','pypj02','pypj03','pypj04'];
// 		for(var f=0;f<3;f++){
// 			document.getElementById(lista[i]).style.display="none";
// 		}
// 		document.getElementById(lista[0]).style.display="flex";
// 		}
// }
// function changesub(value){
// 	var lista = ['pypj01','pypj02','pypj03','pypj04'];
// 	for(var i=0;i<3;i++){
// 		document.getElementById(lista[i]).style.display="none";
// 	}
// 	document.getElementById(value).style.display="flex";
// }