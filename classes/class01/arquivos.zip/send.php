<?php
    $post = json_decode($_POST);
    ini_set( 'display_errors', 1 );
    error_reporting( E_ALL );
    $from = "portifolio@portifolio.com";
    $to = "hikarofcarvalho@gmail.com";
    $subject = $post->name;
    $message = "one person with this email: " . $post->email . " has send to you this message in your portifólio: " . $post->message;
    $headers = "From:" . $from;
    $json_str = '';
    if(mail($to,$subject,$message, $headers)){
        $json_str = '{"message":"This email has Send."}';
    }else{
         $json_str = '{"message":"Error"}';
    }

    //faz o json ser retornado
    $obj = json_decode($json_str);

    echo $obj;
?>