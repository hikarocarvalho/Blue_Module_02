from flask import Flask, render_template, request, redirect
from flask_mail import Mail,Message
app = Flask(__name__) 

mail_settings = {
    "MAIL_SERVER":'smtp.gmail.com',
    "MAIL_PORT":465,
    "MAIL_USE_TSL":False,
    "MAIL_USE_SSL":True,
    "MAIL_USERNAME":'coletivoturmac6blue@gmail.com',
    "MAIL_PASSWORD":'BlueC6123'
}
app.config.update(mail_settings)
mail = Mail(app)

class Contato:
    def __init__(self,input_name,input_email,input_message):
        self.input_name = input_name
        self.input_email = input_email
        self.input_message = input_message
    

@app.route('/') 
def index(): 
    return render_template('index.html')
     
@app.route('/send',methods=['GET', 'POST'])
def send():
    if request.method == 'POST':
        input_name = request.form.get('input_name')
        input_email = request.form.get('input_email')
        input_message = request.form.get('input_message')
        formsend = Contato(input_name,input_email,input_message)

        msg = Message(
            subject='Hikaro',
            sender=app.config.get("MAIL_USERNAME"),
            recipients=[app.config.get("hikarofcarvalho@gmail.com")],
            body=(f'''A pessoa:
            {formsend.input_name} 
            Acaba de enviar uma mensagem com o email:
            {formsend.input_email}
            Onde a mensagem diz:
            {formsend.input_message}
            ''')
        ) 
        mail.send(msg)   
        return redirect('/index.html')
        
    

if __name__ == '__main__':        
    app.run(debug=True)