@app.route('/send',methods=['GET', 'POST'])
# def send():
#     if request.method == 'POST':
#         input_name = request.form.get('input_name')
#         input_email = request.form.get('input_email')
#         input_message = request.form.get('input_message')
#         formsend = Contato(input_name,input_email,input_message)

#         msg = Message(
#             subject='Hikaro',
#             sender=app.config.get("MAIL_USERNAME"),
#             recipients=[app.config.get("hikarofcarvalho@gmail.com")],
#             body=(f'''A pessoa:
#             {formsend.input_name} 
#             Acaba de enviar uma mensagem com o email:
#             {formsend.input_email}
#             Onde a mensagem diz:
#             {formsend.input_message}
#             ''')
#         ) 
#         mail.send(msg)   
#         return redirect('/')
        
    